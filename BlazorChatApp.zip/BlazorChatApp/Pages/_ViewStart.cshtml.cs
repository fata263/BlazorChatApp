using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BlazorChatApp.Pages
{
    public class _ViewStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
